﻿using Stroymaterials.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Stroymaterials.View
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowVM();
            (DataContext as MainWindowVM).LoadData();
        }


        private void BtnAddToDb_Click(object sender, RoutedEventArgs e)
        {
            var AddWindows = new EditWindow(null);
            AddWindows.ShowDialog();
        }
        public void Refrsh()
        {
            (DataContext as MainWindowVM).LoadData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            (DataContext as MainWindowVM).DeleteItenData();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            var AddWindows = new EditWindow((DataContext as MainWindowVM).SelectedItem);
            AddWindows.ShowDialog();
        }
    }
}
