﻿using Stroymaterials.DbEntity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Stroymaterials.ViewModel
{
    public class MainWindowVM : BaseViewModel
    {
        private UserInfo _SelectedItem;
        private ObservableCollection<UserInfo> _userInfo;
        public ObservableCollection<UserInfo> UserInfo
        {
            get => _userInfo;
            set
            {
                _userInfo = value;
                OnPropertyChanged(nameof(UserInfo));
            }
        }
        public UserInfo SelectedItem
        {
            get => _SelectedItem;
            set
            {
                _SelectedItem = value;
                OnPropertyChanged(nameof(SelectedItem));
            }
        }
        public MainWindowVM()
        {
            UserInfo = new ObservableCollection<UserInfo>();

            LoadData();
        }

        public void LoadData()
        {
            if (UserInfo.Count != 0)
            {
                UserInfo.Clear();
            }

            var result = DbBuildMaterial.Dd.UserInfo.ToList();
            result.ForEach(elem => UserInfo?.Add(elem));
        }
        public void DeleteItenData()
        {
            if (!(SelectedItem is null))
            {
                using (var db = new BuildMaterialsEntities())
                {
                    var result = MessageBox.Show("Вы действительно хотите удалить этот элемент?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        try
                        {
                            var ItemForDelete = db.UserInfo.Where(elem => elem.UserInfoId == SelectedItem.UserInfoId).FirstOrDefault();
                            db.UserInfo.Remove(ItemForDelete);
                            db.SaveChanges();
                            LoadData();
                            MessageBox.Show("Данные успешно удалены", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }
            }
        }
    }
}

