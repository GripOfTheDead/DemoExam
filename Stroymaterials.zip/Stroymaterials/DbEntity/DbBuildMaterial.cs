﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stroymaterials.DbEntity
{
    public class DbBuildMaterial
    {
        public static BuildMaterialsEntities Dd { get; set; } = new BuildMaterialsEntities();
    }
}
